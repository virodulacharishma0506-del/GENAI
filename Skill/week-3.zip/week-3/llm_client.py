import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass

import requests


@dataclass
class LLMResult:
    text: str
    input_tokens: int
    output_tokens: int


class LLMProvider(ABC):
    @abstractmethod
    def generate(self, prompt):
        pass


# Hosted Gemini provider (REST API via requests, 5s connect / 60s read timeout)
class GeminiProvider(LLMProvider):
    provider_name = "Gemini"

    def __init__(self, api_key, model="gemini-2.5-flash"):
        self.api_key = api_key
        self.model = model
        self.url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{model}:generateContent"
        )

    def generate(self, prompt):
        response = requests.post(
            self.url,
            headers={"x-goog-api-key": self.api_key},
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=(5, 60),
        )
        response.raise_for_status()
        data = response.json()
        usage = data.get("usageMetadata", {})
        parts = data["candidates"][0].get("content", {}).get("parts", [])
        text = "".join(p.get("text", "") for p in parts)
        return LLMResult(
            text=text,
            input_tokens=usage.get("promptTokenCount", 0) or 0,
            output_tokens=usage.get("candidatesTokenCount", 0) or 0,
        )


# Local Ollama provider
class OllamaProvider(LLMProvider):
    provider_name = "Ollama"

    def __init__(self, model="llama3.2"):
        self.model = model
        self.url = "http://localhost:11434/api/generate"

    def generate(self, prompt):
        response = requests.post(
            self.url,
            json={"model": self.model, "prompt": prompt, "stream": False},
            timeout=(5, 60),
        )
        response.raise_for_status()
        data = response.json()
        return LLMResult(
            text=data.get("response", ""),
            input_tokens=data.get("prompt_eval_count", 0) or 0,
            output_tokens=data.get("eval_count", 0) or 0,
        )


RETRYABLE_STATUS = (408, 429, 500, 502, 503, 504)


def is_retryable(error):
    if isinstance(
        error, (requests.exceptions.Timeout, requests.exceptions.ConnectionError)
    ):
        return True
    status = getattr(error, "status_code", None)
    if status is None:
        status = getattr(getattr(error, "response", None), "status_code", None)
    return status in RETRYABLE_STATUS


class LLMClient:
    def __init__(self, provider, usage_logger, max_attempts=3, sleep=time.sleep):
        self.provider = provider
        self.usage_logger = usage_logger
        self.max_attempts = max_attempts
        self.sleep = sleep

    def _cost(self, result):
        if self.provider.provider_name == "Gemini":
            input_rate = float(os.getenv("GEMINI_INPUT_PRICE_PER_MILLION", "0"))
            output_rate = float(os.getenv("GEMINI_OUTPUT_PRICE_PER_MILLION", "0"))
            cost = (
                result.input_tokens * input_rate
                + result.output_tokens * output_rate
            ) / 1_000_000
            return cost, "estimated_hosted_api_cost"
        # Local Ollama has no hosted API token charge.
        return 0.0, "local_inference_cost_not_included"

    def generate(self, prompt):
        start = time.perf_counter()
        for attempt in range(self.max_attempts):
            try:
                result = self.provider.generate(prompt)
                latency_ms = round((time.perf_counter() - start) * 1000, 2)
                cost, cost_type = self._cost(result)

                self.usage_logger.log_call({
                    "provider": self.provider.provider_name,
                    "model": self.provider.model,
                    "input_tokens": result.input_tokens,
                    "output_tokens": result.output_tokens,
                    "total_tokens": result.input_tokens + result.output_tokens,
                    "latency_ms": latency_ms,
                    "estimated_cost_usd": round(cost, 8),
                    "cost_type": cost_type,
                    "status": "success",
                    "attempts": attempt + 1,
                })
                print(f"Latency: {latency_ms} ms")
                print(f"Input tokens: {result.input_tokens}")
                print(f"Output tokens: {result.output_tokens}")
                print(f"Estimated cost (USD): {cost}")
                return result.text

            except Exception as error:
                if not is_retryable(error) or attempt == self.max_attempts - 1:
                    latency_ms = round((time.perf_counter() - start) * 1000, 2)
                    self.usage_logger.log_call({
                        "provider": self.provider.provider_name,
                        "model": self.provider.model,
                        "input_tokens": None,
                        "output_tokens": None,
                        "total_tokens": None,
                        "latency_ms": latency_ms,
                        "estimated_cost_usd": None,
                        "status": "failed",
                        "attempts": attempt + 1,
                        "error": str(error),
                    })
                    raise
                delay = 2 ** attempt
                print(
                    f"Temporary error. Retry {attempt + 1} "
                    f"of {self.max_attempts - 1} in {delay} seconds."
                )
                self.sleep(delay)
