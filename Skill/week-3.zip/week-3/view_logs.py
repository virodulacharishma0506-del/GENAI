"""Print the latest usage records stored in MongoDB (useful for a screenshot)."""
import os

from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv(override=True)
client = MongoClient(os.getenv("MONGODB_URI"), serverSelectionTimeoutMS=5000)
for doc in client["llm_monitoring"]["api_usage"].find().sort("timestamp", -1).limit(10):
    doc.pop("_id", None)
    print(doc)
client.close()
