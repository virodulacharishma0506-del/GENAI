import unittest
from unittest.mock import patch, MagicMock

import requests

from llm_client import LLMClient, LLMResult, GeminiProvider


class FakeProvider:
    provider_name = "Test"
    model = "fake-model"

    def generate(self, prompt):
        return LLMResult(
            text="AI stands for Artificial Intelligence.",
            input_tokens=5,
            output_tokens=8,
        )


class FlakyProvider(FakeProvider):
    """Fails with a temporary error twice, then succeeds."""

    def __init__(self):
        self.calls = 0

    def generate(self, prompt):
        self.calls += 1
        if self.calls < 3:
            raise requests.exceptions.ConnectionError("temporary")
        return super().generate(prompt)


class BadRequestProvider(FakeProvider):
    def generate(self, prompt):
        raise ValueError("bad request")


class FakeLogger:
    def __init__(self):
        self.records = []

    def log_call(self, record):
        self.records.append(record)
        return True


class TestLLMClient(unittest.TestCase):
    def test_generate_and_log_usage(self):
        logger = FakeLogger()
        client = LLMClient(FakeProvider(), logger)
        answer = client.generate("Explain AI")
        self.assertEqual(answer, "AI stands for Artificial Intelligence.")
        self.assertEqual(len(logger.records), 1)
        self.assertEqual(logger.records[0]["total_tokens"], 13)
        self.assertEqual(logger.records[0]["status"], "success")

    def test_retries_temporary_errors(self):
        logger = FakeLogger()
        provider = FlakyProvider()
        client = LLMClient(provider, logger, sleep=lambda s: None)
        client.generate("hi")
        self.assertEqual(provider.calls, 3)
        self.assertEqual(logger.records[0]["attempts"], 3)

    def test_non_retryable_error_is_logged_as_failed(self):
        logger = FakeLogger()
        client = LLMClient(BadRequestProvider(), logger, sleep=lambda s: None)
        with self.assertRaises(ValueError):
            client.generate("hi")
        self.assertEqual(logger.records[0]["status"], "failed")
        self.assertEqual(logger.records[0]["attempts"], 1)

    @patch.dict("os.environ", {
        "GEMINI_INPUT_PRICE_PER_MILLION": "0.30",
        "GEMINI_OUTPUT_PRICE_PER_MILLION": "2.50",
    })
    @patch("llm_client.requests.post")
    def test_gemini_tokens_and_cost(self, mock_post):
        resp = MagicMock()
        resp.json.return_value = {
            "candidates": [{"content": {"parts": [{"text": "hello"}]}}],
            "usageMetadata": {"promptTokenCount": 1000, "candidatesTokenCount": 2000},
        }
        mock_post.return_value = resp
        logger = FakeLogger()
        client = LLMClient(GeminiProvider("key"), logger)
        self.assertEqual(client.generate("hi"), "hello")
        rec = logger.records[0]
        self.assertEqual(rec["total_tokens"], 3000)
        self.assertAlmostEqual(rec["estimated_cost_usd"], 0.0053)


if __name__ == "__main__":
    unittest.main()
