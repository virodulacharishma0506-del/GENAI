# Week 3 - Logging Tokens, Latency and Cost for Gemini API Calls (MongoDB)

## Setup (PowerShell)
    python -m venv myenv
    .\myenv\Scripts\Activate.ps1
    pip install -r requirements.txt
    copy .env.example .env      # then edit .env with your keys

## Run
    python check_models.py      # list available Gemini models
    python test_mongodb.py      # test MongoDB Atlas connection
    python main.py              # main monitoring app
    python view_logs.py         # summary + usage_chart.png

## Ollama (local LLM)
    ollama --version
    ollama list
    ollama run llama3.2:1b
