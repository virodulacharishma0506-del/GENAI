import unittest
from unittest.mock import patch, MagicMock

from llm_client import LLMClient, LLMProvider, OllamaProvider


# Fake provider for testing
class FakeProvider(LLMProvider):
    def generate(self, prompt):
        return "AI stands for Artificial Intelligence."


class TestLLMClient(unittest.TestCase):
    def test_generate(self):
        client = LLMClient(FakeProvider())
        self.assertEqual(
            client.generate("Explain AI"),
            "AI stands for Artificial Intelligence.",
        )

    def test_providers_are_interchangeable(self):
        a, b = LLMClient(FakeProvider()), LLMClient(FakeProvider())
        self.assertEqual(a.generate("x"), b.generate("x"))

    @patch("llm_client.requests.post")
    def test_ollama_provider(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"response": "hello"}
        mock_post.return_value = mock_resp
        self.assertEqual(OllamaProvider().generate("hi"), "hello")
        mock_resp.raise_for_status.assert_called_once()


if __name__ == "__main__":
    unittest.main()
